# ESP-General + ST7789 1.54" 240x240 — source only

Only the ESP-General board definition is included; other board definitions have
been removed.

Display:
- ST7789, 240x240
- SCLK GPIO18
- MOSI GPIO23
- CS GPIO5
- DC GPIO2
- RST GPIO4
- Backlight GPIO32
- MISO unused
- Touch disabled

PlatformIO environment: `esp32-s3-devkitc-1`

This package contains source code only; it is not a precompiled .bin.
