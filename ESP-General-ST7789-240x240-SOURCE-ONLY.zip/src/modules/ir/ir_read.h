#include <IRrecv.h>
#include <globals.h>

class IrRead {
public:
    IRrecv irrecv = IRrecv(bruceConfigPins.irRx, SAFE_STACK_BUFFER_SIZE / 2, 50);

    IrRead(bool headless_mode = false, bool raw_mode = false);

    void setup();
    void loop();
    void quickLoop();

    String loop_headless(int max_loops);

private:
    bool _read_signal = false;
    bool _emulate_mode = false;
    String _captured_raw_signal = "";
    decode_results results;
    uint16_t *rawcode;
    uint16_t raw_data_len;
    int signals_read = 0;
    int button_pos = 0;
    String strDeviceContent = "";
    bool headless = false;
    bool raw = false;

    void cls();
    void display_banner();
    void display_btn_options();

    void begin();
    void read_signal();
    void emulate_signal();
    void save_device();
    void save_signal();
    void discard_signal();
    void append_to_file_str(const String &btn_name);
    bool write_file(String filename, FS *fs);
    String parse_raw_signal();
    String parse_state_signal();

    std::vector<String> quickButtonsTV = {"POWER", "UP",   "DOWN", "LEFT",  "RIGHT", "OK",       "SOURCES",
                                          "VOL+",  "VOL-", "CHA+", "CHA-",  "MUTE",  "SETTINGS", "NETFLIX",
                                          "HOME",  "BACK", "EXIT", "SMART", "1",     "2",        "3",
                                          "4",     "5",    "6",    "7",     "8",     "9",        "0"};
    std::vector<String> quickButtonsAC = {
        "POWER", "TEMP+", "TEMP-", "SPEED", "SWING", "SWING+", "SWING-", "JET", "UP", "DOWN", "MODE"
    };
    std::vector<String> quickButtonsFAN = {
        "POWER",
        "SPEED+",
        "SPEED-",
        "MODE",
        "TIMER",
        "SWING",
        "OSCILLATE",
        "UP",
        "DOWN",
        "LIGHT",
        "ION",
        "SLEEP"
    };
    std::vector<String> quickButtonsSOUND = {"POWER",    "UP",      "DOWN", "LEFT",    "RIGHT",
                                             "OK",       "SOURCES", "VOL+", "VOL-",    "MUTE",
                                             "SETTINGS", "BACK",    "EQ",   "REC",     "PLAY/PAUSE",
                                             "STOP",     "NEXT",    "PREV", "SHUFFLE", "REPEAT"};
    std::vector<String> quickButtonsLED = {"ON",         "OFF",          "BRIGHTNESS+", "BRIGHTNESS-",
                                           "RED",        "GREEN",        "BLUE",        "WHITE",
                                           "ORANGE",     "PEA_GREEN",    "DARK_BLUE",   "DARK_YELLOW",
                                           "CYAN",       "PURPLE",       "YELLOW",      "LIGHT_BLUE",
                                           "MAGENTA",    "LIGHT_YELLOW", "SKY_BLUE",    "ROSE",
                                           "MODE_FLASH", "MODE_STROBE",  "MODE_FADE",   "MODE_SMOOTH"};
    std::vector<String> &quickButtons = quickButtonsTV;
};
